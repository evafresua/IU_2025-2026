
datosgenerales = Array("Eva Freire Suarez", "ET2", 40);

